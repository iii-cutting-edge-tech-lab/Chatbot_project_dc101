#!/bin/bash
if [ `docker ps | wc -l` = 3 ]
then
        docker-compose down
fi
